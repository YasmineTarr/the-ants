import UIKit

var ants = 1

while ants < 10{
    print("The ants go marching \(ants) by \(ants),")
    print( "Hurrah, hurrah,")
    print( "he ants go marching \(ants) by \(ants),")
    print( "Hurrah, hurrah,")
    print( "The ants go marching \(ants) by \(ants),")
    print( "And they all go marching down,")
    print("to the ground, to get out of the rain,")
    print( "Boom boom boom.")
    ants = ants + 1
}
if ants == 10 {
    print("The little one stops to shout, The End!")
}
if ants > 10{
    ants = 10
}

